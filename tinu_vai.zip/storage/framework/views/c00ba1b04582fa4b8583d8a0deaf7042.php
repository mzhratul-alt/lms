<?php $__env->startSection('page_title', 'Admin - Dashboard'); ?>
<?php $__env->startSection('admin_main_content'); ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\1.Laravel\tinu_vai\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>